import { Layout } from "@/components/Layout";

const Chat = () => {
  return <Layout />;
};

export default Chat;